package nl.novi.javaprogrammeren.three;

public class MainThree {

    public static void main(String[] args) {
   }
}
