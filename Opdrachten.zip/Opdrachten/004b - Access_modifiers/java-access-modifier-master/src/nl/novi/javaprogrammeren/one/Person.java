package nl.novi.javaprogrammeren.one;

public class Person {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    private String getName() {
        return name;
    }

}
