package nl.novi.javaprogrammeren.four;

public class MainFour {
    public static void main(String[] args) {

    }
}
