package nl.novi.javaprogrammeren.four.hidden;

public class PrisonCell {
}
