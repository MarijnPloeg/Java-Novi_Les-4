package nl.novi.javaprogrammeren.two.sub;

public class Phone {
    private String brand;

    public Phone(String brand) {
        this.brand = brand;
    }

    String getBrand() {
        return brand;
    }
}
