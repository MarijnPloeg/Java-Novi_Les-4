package nl.novi.javaprogrammeren.three.sub;

public class Human {
    private String sofiNumber;

    public Human(String sofiNumber) {
        this.sofiNumber = sofiNumber;
    }

    protected String getSofiNumber() {
        return sofiNumber;
    }
}
