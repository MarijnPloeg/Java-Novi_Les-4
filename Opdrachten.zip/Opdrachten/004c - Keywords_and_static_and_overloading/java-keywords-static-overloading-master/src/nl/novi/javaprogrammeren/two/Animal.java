package nl.novi.javaprogrammeren.two;

public final class Animal {

    private int amountOfLegs;
    private String name;

}
