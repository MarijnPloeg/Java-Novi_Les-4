package nl.novi.javaprogrammeren.three;

public class Beer {
    private String brand;

    public Beer(String brand) {
        this.brand = brand;
    }
}
