package nl.novi.javaprogrammeren.four.hidden;

public class HumanMaker {

    private HumanMaker() {
    }
}
