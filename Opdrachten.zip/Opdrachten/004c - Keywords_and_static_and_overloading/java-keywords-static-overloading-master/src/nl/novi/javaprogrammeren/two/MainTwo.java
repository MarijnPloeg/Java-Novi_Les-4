package nl.novi.javaprogrammeren.two;

public class MainTwo {

    public static void main(String[] args) {

    }
}
