package nl.novi.javaprogrammeren.four.hidden;

public class Human {
    private String name;

    Human(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }
}
